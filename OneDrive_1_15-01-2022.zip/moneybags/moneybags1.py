def nidal():
    a = 10
    
    
def hello():
    nidal()
    print(a)
    
hello()